﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

    

namespace wLinea
{
    class clsLinea
    {
        private int x;
        private int y;
        private int xfinal;
        private int yfinal;

        private static int contar = 0;

        public clsLinea()
        {
            x = 0;
            y = 0;
            xfinal = 0;
            yfinal = 0;
        }

        public clsLinea(int x, int y, int xfinal, int yfinal)
        {
            this.x = x;
            this.y = y;
            this.xfinal = xfinal;
            this.yfinal = yfinal;

        }

        public clsLinea(double x, double y, double xfinal, double yfinal)
        {
            this.x = (int)x;
            this.y = (int)y;
            this.xfinal = (int)xfinal;
            this.yfinal = (int)yfinal;
        }

        public int obtenX()
        {
            return x;
        }

        public int obtenY()
        {
            return y;
        }

        public int obtenxfinal()
        {
            return xfinal;
        }

        public int obtenyfinal()
        {
            return yfinal;
        }

        public void cambiarX(int x)
        {
            this.x = x;
        }
        public void cambiarY(int y)
        {
            this.y = y;
        }
        public void cambiarxfinal(int xfinal)
        {
            this.xfinal = xfinal;
        }
        public void cambiaryfinal(int yfinal)
        {
            this.yfinal = yfinal;
        }


        public static int obtenCuenta()
        {
            contar += 1;
            return contar;
        }
    }

}

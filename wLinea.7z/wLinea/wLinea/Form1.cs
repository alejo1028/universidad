﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
/// Fecha: Marzo 14 de 2023
/// Autor: Alejandro Ramirez Florez
/// Descripción: Aplicación de dibujar línea
/// </summary>

namespace wLinea
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            int x = int x.Parse(txtX.Text)
            int y = int y.Parse(txtY.Text)
            int xfinal = int xfinal.Parse(txtXF.Text)
            int yfinal = int yfinal.parse(txtYF.Text)


        }
    }
}
